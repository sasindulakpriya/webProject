A Pen created at CodePen.io. You can find this one at https://codepen.io/rtpHarry/pen/YPBydd.

 This is a modification to the standard Bootstrap carousel which lets you show four panels at once but only slide them along one panel at a time. 

It is responsive and modifies the number of panels shown at a time on smaller screens.

Credit: I found the [original concept on Bootply](http://www.bootply.com/TkEfjDBeRP) but unfortunately tracing it back as far as the thread went started out with an anon post. This version is almost a complete rewrite and incorporates back button anim fix, responsive design, updated to work with new BS3 CSS transitions, container class anim fix, LESS styling, and optimized JS.